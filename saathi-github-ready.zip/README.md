# 🚑 SAATHI — Emergency Healthcare Response Network

From emergency detection to the right help — faster.

SAATHI lets a user trigger an emergency, share live location, notify responders, keep a medical profile (blood group, allergies, conditions, contacts), and find nearby hospitals. It also includes health-guidance screens (diet, exercise, diagnostics, chatbot).

## Repository structure

```
.
├── medi-ally-frontend/   # React 18 + Vite + Tailwind client
└── medi-ally-backend/    # Node.js + Express + Socket.IO API
```

## Tech stack

- **Frontend:** React 18, Vite, Tailwind CSS, Zustand, React Router, Framer Motion, Recharts, React Leaflet, Axios, Socket.IO client
- **Backend:** Node.js, Express, Socket.IO, Mongoose (MongoDB), JWT auth, bcryptjs

## Getting started

Requires Node.js >= 18.

### 1. Backend

```bash
cd medi-ally-backend
cp .env.example .env      # then edit values (set a real JWT_SECRET)
npm install
npm run dev               # http://localhost:8000
```

### 2. Frontend

```bash
cd medi-ally-frontend
cp .env.example .env
npm install
npm run dev               # http://localhost:5173
```

See `medi-ally-frontend/README.md` for more frontend details.
