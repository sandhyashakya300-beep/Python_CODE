const mongoose = require('mongoose');

const responderSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    available: { type: Boolean, default: true },
    latitude: Number,
    longitude: Number,
    lastLocationUpdate: Date,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Responder', responderSchema);
