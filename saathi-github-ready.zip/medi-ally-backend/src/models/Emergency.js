const mongoose = require('mongoose');

const emergencySchema = new mongoose.Schema(
  {
    publicId: { type: String, required: true, unique: true },
    patientId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    type: { type: String, required: true },
    description: { type: String, default: '' },
    latitude: Number,
    longitude: Number,
    accuracy: Number,
    medicalSnapshot: {
      age: Number,
      bloodGroup: String,
      allergies: [String],
      conditions: [String],
      medications: [String],
      emergencyContacts: [
        {
          name: String,
          relation: String,
          phone: String,
        },
      ],
    },
    responderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    status: {
      type: String,
      enum: ['SEARCHING', 'ACCEPTED', 'ON_THE_WAY', 'ARRIVED', 'RESOLVED', 'CANCELLED'],
      default: 'SEARCHING',
    },
    createdAt: { type: Date, default: Date.now },
    acceptedAt: Date,
    resolvedAt: Date,
    cancelledAt: Date,
    updatedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Emergency', emergencySchema);
