const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true },
    phone: { type: String, default: '' },
    role: { type: String, enum: ['PATIENT', 'RESPONDER', 'ADMIN'], default: 'PATIENT' },
    profile: {
      age: Number,
      height: Number,
      weight: Number,
      bloodGroup: String,
      allergies: [String],
      conditions: [String],
      medications: [String],
      emergencyContacts: [
        {
          name: String,
          relation: String,
          phone: String,
        },
      ],
      medicalHistory: [String],
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);
