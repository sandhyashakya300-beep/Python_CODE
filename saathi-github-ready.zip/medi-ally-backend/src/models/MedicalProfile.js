const mongoose = require('mongoose');

const medicalProfileSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    age: Number,
    bloodGroup: String,
    allergies: [String],
    conditions: [String],
    medications: [String],
    emergencyContacts: [
      {
        name: String,
        relation: String,
        phone: String,
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model('MedicalProfile', medicalProfileSchema);
