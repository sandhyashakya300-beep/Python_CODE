const express = require('express');
const { requireAuth } = require('../middleware/auth');
const { updateUserProfile, findUserById, sanitizeUser } = require('../services/inMemoryStore');

const router = express.Router();

router.get('/me', requireAuth, (req, res) => {
  const user = findUserById(req.user.id);
  if (!user) {
    return res.status(404).json({ message: 'User not found.' });
  }

  res.json({ user: sanitizeUser(user) });
});

router.put('/me', requireAuth, (req, res) => {
  const userId = req.user.id;
  const profileUpdates = req.body || {};

  const updatedUser = updateUserProfile(userId, profileUpdates);
  if (!updatedUser) {
    return res.status(404).json({ message: 'User not found.' });
  }

  res.json({ user: updatedUser });
});

module.exports = router;
