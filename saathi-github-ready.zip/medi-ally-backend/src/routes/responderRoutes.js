const express = require('express');
const { requireAuth } = require('../middleware/auth');
const { findUserById, upsertResponderStatus, listAvailableResponders } = require('../services/inMemoryStore');

const router = express.Router();

router.get('/online', requireAuth, (req, res) => {
  const user = findUserById(req.user.id);
  if (!user) {
    return res.status(404).json({ message: 'User not found.' });
  }

  res.json({ responders: listAvailableResponders() });
});

router.post('/availability', requireAuth, (req, res) => {
  const { available, latitude, longitude } = req.body || {};

  const responder = upsertResponderStatus(req.user.id, {
    available: Boolean(available),
    latitude,
    longitude,
  });

  req.app.locals.io.emit('responder:update', {
    userId: req.user.id,
    responder,
  });

  res.json({ responder });
});

module.exports = router;
