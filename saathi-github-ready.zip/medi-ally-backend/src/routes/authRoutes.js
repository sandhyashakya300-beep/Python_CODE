const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { createUser, findUserByEmail, sanitizeUser } = require('../services/inMemoryStore');

const router = express.Router();

const signToken = (user) =>
  jwt.sign({ userId: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET || 'saathi-dev-secret', {
    expiresIn: '7d',
  });

router.post('/register', async (req, res, next) => {
  try {
    const { name, email, password, phone, role } = req.body || {};

    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Name, email, and password are required.' });
    }

    if (findUserByEmail(email)) {
      return res.status(409).json({ message: 'An account with this email already exists.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = createUser({ name, email, password: hashedPassword, phone, role });
    const token = signToken(newUser);

    res.status(201).json({
      token,
      user: {
        ...newUser,
        profile: newUser.profile || {
          age: null,
          height: null,
          weight: null,
          bloodGroup: '',
          allergies: [],
          conditions: [],
          medications: [],
          emergencyContacts: [],
          medicalHistory: [],
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body || {};

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required.' });
    }

    const user = findUserByEmail(email);
    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    const token = signToken(user);
    const safeUser = sanitizeUser(user);

    res.json({ token, user: safeUser });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
