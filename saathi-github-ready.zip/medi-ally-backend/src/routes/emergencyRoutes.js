const express = require('express');
const { requireAuth } = require('../middleware/auth');
const {
  createEmergency,
  listEmergencies,
  findEmergencyById,
  attachResponder,
  cancelEmergency,
  resolveEmergency,
  findUserById,
  listAvailableResponders,
} = require('../services/inMemoryStore');

const router = express.Router();

router.get('/', requireAuth, (req, res) => {
  res.json({ emergencies: listEmergencies() });
});

router.post('/', requireAuth, (req, res) => {
  const { type, description, latitude, longitude, accuracy, medicalSnapshot } = req.body || {};

  if (!type) {
    return res.status(400).json({ message: 'Emergency type is required.' });
  }

  const emergency = createEmergency({
    patientId: req.user.id,
    type,
    description,
    latitude,
    longitude,
    accuracy,
    medicalSnapshot: medicalSnapshot || {
      age: req.user.profile?.age ?? null,
      bloodGroup: req.user.profile?.bloodGroup ?? '',
      allergies: req.user.profile?.allergies ?? [],
      conditions: req.user.profile?.conditions ?? [],
      medications: req.user.profile?.medications ?? [],
      emergencyContacts: req.user.profile?.emergencyContacts ?? [],
    },
  });

  req.app.locals.io.emit('emergency:update', emergency);

  res.status(201).json({ emergency });
});

router.get('/:id', requireAuth, (req, res) => {
  const emergency = findEmergencyById(req.params.id);
  if (!emergency) {
    return res.status(404).json({ message: 'Emergency not found.' });
  }

  res.json({ emergency });
});

router.post('/:id/accept', requireAuth, (req, res) => {
  const emergency = findEmergencyById(req.params.id);
  if (!emergency) {
    return res.status(404).json({ message: 'Emergency not found.' });
  }

  const responderId = req.user.id;
  const accepted = attachResponder(emergency.id, responderId);
  if (!accepted) {
    return res.status(400).json({ message: 'Emergency cannot be accepted in its current state.' });
  }

  req.app.locals.io.emit('emergency:update', accepted);
  res.json({ emergency: accepted });
});

router.post('/:id/cancel', requireAuth, (req, res) => {
  const emergency = findEmergencyById(req.params.id);
  if (!emergency) {
    return res.status(404).json({ message: 'Emergency not found.' });
  }

  const cancelled = cancelEmergency(emergency.id);
  req.app.locals.io.emit('emergency:update', cancelled);
  res.json({ emergency: cancelled });
});

router.post('/:id/resolve', requireAuth, (req, res) => {
  const emergency = findEmergencyById(req.params.id);
  if (!emergency) {
    return res.status(404).json({ message: 'Emergency not found.' });
  }

  const resolved = resolveEmergency(emergency.id);
  req.app.locals.io.emit('emergency:update', resolved);
  res.json({ emergency: resolved });
});

router.get('/status/summary', requireAuth, (req, res) => {
  const emergencies = listEmergencies();
  const responders = listAvailableResponders();

  res.json({
    total: emergencies.length,
    active: emergencies.filter((emergency) => !['RESOLVED', 'CANCELLED'].includes(emergency.status)).length,
    responders: responders.length,
  });
});

module.exports = router;
