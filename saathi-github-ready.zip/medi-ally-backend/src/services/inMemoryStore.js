const crypto = require('crypto');

const store = {
  users: [],
  emergencies: [],
  responders: [],
};

const getPublicId = () => `SA-${Math.floor(1000 + Math.random() * 9000)}`;

const sanitizeUser = (user) => {
  if (!user) return null;
  const { password, ...safeUser } = user;
  return safeUser;
};

const appendUser = (user) => {
  store.users.push(user);
  return sanitizeUser(user);
};

const findUserByEmail = (email) =>
  store.users.find((user) => user.email.toLowerCase() === String(email).toLowerCase());

const findUserById = (userId) => store.users.find((user) => user.id === String(userId));

const createUser = ({ name, email, password, phone, role }) => {
  const normalizedUser = {
    id: `user-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    name,
    email,
    phone: phone || '',
    password,
    role: role || 'PATIENT',
    createdAt: new Date().toISOString(),
    profile: {
      age: null,
      height: null,
      weight: null,
      bloodGroup: '',
      allergies: [],
      conditions: [],
      medications: [],
      emergencyContacts: [],
      medicalHistory: [],
    },
  };

  store.users.push(normalizedUser);
  return sanitizeUser(normalizedUser);
};

const updateUserProfile = (userId, profileUpdates) => {
  const user = findUserById(userId);
  if (!user) return null;

  user.profile = {
    ...user.profile,
    ...profileUpdates,
  };

  user.age = profileUpdates.age ?? user.age ?? null;
  user.height = profileUpdates.height ?? user.height ?? null;
  user.weight = profileUpdates.weight ?? user.weight ?? null;
  user.bloodGroup = profileUpdates.bloodGroup ?? user.bloodGroup ?? '';
  user.allergies = profileUpdates.allergies ?? user.allergies ?? [];
  user.conditions = profileUpdates.conditions ?? user.conditions ?? [];
  user.medications = profileUpdates.medications ?? user.medications ?? [];
  user.emergencyContacts = profileUpdates.emergencyContacts ?? user.emergencyContacts ?? [];
  user.medicalHistory = profileUpdates.medicalHistory ?? user.medicalHistory ?? [];

  return sanitizeUser(user);
};

const createResponder = ({ userId, available, latitude, longitude }) => {
  const responder = {
    id: `responder-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    userId,
    available: Boolean(available),
    latitude: latitude ?? null,
    longitude: longitude ?? null,
    lastLocationUpdate: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  };

  store.responders.push(responder);
  return responder;
};

const findResponderByUserId = (userId) =>
  store.responders.find((responder) => responder.userId === String(userId));

const listAvailableResponders = () => store.responders.filter((responder) => responder.available);

const upsertResponderStatus = (userId, updates) => {
  let responder = findResponderByUserId(userId);

  if (!responder) {
    responder = createResponder({ userId, available: true, ...updates });
    return responder;
  }

  Object.assign(responder, {
    ...updates,
    lastLocationUpdate: new Date().toISOString(),
  });

  return responder;
};

const findEmergencyById = (id) => store.emergencies.find((emergency) => emergency.id === String(id) || emergency.publicId === String(id));

const listEmergencies = () => [...store.emergencies].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

const createEmergency = ({ patientId, type, description, latitude, longitude, accuracy, medicalSnapshot, status = 'SEARCHING' }) => {
  const emergency = {
    id: `emergency-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    publicId: getPublicId(),
    patientId: String(patientId),
    type,
    description: description || '',
    latitude: latitude ?? null,
    longitude: longitude ?? null,
    accuracy: accuracy ?? null,
    medicalSnapshot: medicalSnapshot || null,
    responderId: null,
    status,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    acceptedAt: null,
    resolvedAt: null,
    cancelledAt: null,
    timeline: [
      {
        status: 'SEARCHING',
        timestamp: new Date().toISOString(),
      },
    ],
    history: [],
  };

  store.emergencies.push(emergency);
  return emergency;
};

const updateEmergency = (emergencyId, updates) => {
  const emergency = findEmergencyById(emergencyId);
  if (!emergency) return null;

  Object.assign(emergency, updates, {
    updatedAt: new Date().toISOString(),
  });

  if (updates.status) {
    emergency.timeline = [
      ...emergency.timeline,
      {
        status: updates.status,
        timestamp: new Date().toISOString(),
      },
    ];
  }

  return emergency;
};

const attachResponder = (emergencyId, responderId) => {
  const emergency = findEmergencyById(emergencyId);
  if (!emergency || emergency.status === 'CANCELLED' || emergency.status === 'RESOLVED') return null;
  emergency.responderId = responderId;
  emergency.status = 'ACCEPTED';
  emergency.acceptedAt = new Date().toISOString();
  emergency.updatedAt = new Date().toISOString();
  emergency.timeline = [
    ...emergency.timeline,
    { status: 'ACCEPTED', timestamp: new Date().toISOString() },
  ];
  return emergency;
};

const cancelEmergency = (emergencyId) => {
  const emergency = findEmergencyById(emergencyId);
  if (!emergency) return null;
  emergency.status = 'CANCELLED';
  emergency.cancelledAt = new Date().toISOString();
  emergency.updatedAt = new Date().toISOString();
  emergency.timeline = [
    ...emergency.timeline,
    { status: 'CANCELLED', timestamp: new Date().toISOString() },
  ];
  return emergency;
};

const resolveEmergency = (emergencyId) => {
  const emergency = findEmergencyById(emergencyId);
  if (!emergency) return null;
  emergency.status = 'RESOLVED';
  emergency.resolvedAt = new Date().toISOString();
  emergency.updatedAt = new Date().toISOString();
  emergency.timeline = [
    ...emergency.timeline,
    { status: 'RESOLVED', timestamp: new Date().toISOString() },
  ];
  return emergency;
};

module.exports = {
  store,
  findUserByEmail,
  findUserById,
  createUser,
  updateUserProfile,
  appendUser,
  sanitizeUser,
  createResponder,
  findResponderByUserId,
  listAvailableResponders,
  upsertResponderStatus,
  findEmergencyById,
  listEmergencies,
  createEmergency,
  updateEmergency,
  attachResponder,
  cancelEmergency,
  resolveEmergency,
  getPublicId,
  crypto,
};
