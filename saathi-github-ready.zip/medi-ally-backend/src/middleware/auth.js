const jwt = require('jsonwebtoken');
const { findUserById } = require('../services/inMemoryStore');

function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || ' ';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ message: 'Authentication required.' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'saathi-dev-secret');
    const user = findUserById(decoded.userId);

    if (!user) {
      return res.status(401).json({ message: 'Invalid or expired token.' });
    }

    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid or expired token.' });
  }
}

module.exports = { requireAuth };
