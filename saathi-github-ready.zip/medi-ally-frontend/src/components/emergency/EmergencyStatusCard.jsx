import React from 'react';
import { motion } from 'framer-motion';
import { Activity, Clock3, MapPin, Siren } from 'lucide-react';

const statusStyles = {
  SEARCHING: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200',
  ACCEPTED: 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-200',
  ON_THE_WAY: 'bg-violet-100 text-violet-800 dark:bg-violet-900/40 dark:text-violet-200',
  ARRIVED: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
  RESOLVED: 'bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-200',
  CANCELLED: 'bg-slate-200 text-slate-800 dark:bg-slate-700 dark:text-slate-200',
};

const EmergencyStatusCard = ({ emergency }) => {
  if (!emergency) return null;

  const statusLabel = emergency.status?.replace('_', ' ');

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 p-5 shadow-soft"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-danger-50 dark:bg-danger-900/30 p-2 text-danger-600">
            <Siren size={20} />
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-surface-500">Live emergency status</p>
            <h3 className="mt-1 text-lg font-semibold text-surface-900 dark:text-white">#{emergency.publicId || emergency.id}</h3>
          </div>
        </div>
        <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${statusStyles[emergency.status] || statusStyles.SEARCHING}`}>
          {statusLabel}
        </span>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <div className="rounded-xl bg-surface-50 dark:bg-surface-700/40 p-3">
          <div className="flex items-center gap-2 text-surface-500 text-xs uppercase tracking-wide">
            <Activity size={14} />
            Type
          </div>
          <p className="mt-2 font-medium text-surface-900 dark:text-white">{emergency.type}</p>
        </div>
        <div className="rounded-xl bg-surface-50 dark:bg-surface-700/40 p-3">
          <div className="flex items-center gap-2 text-surface-500 text-xs uppercase tracking-wide">
            <Clock3 size={14} />
            Updated
          </div>
          <p className="mt-2 font-medium text-surface-900 dark:text-white">
            {new Date(emergency.updatedAt || emergency.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </p>
        </div>
        <div className="rounded-xl bg-surface-50 dark:bg-surface-700/40 p-3">
          <div className="flex items-center gap-2 text-surface-500 text-xs uppercase tracking-wide">
            <MapPin size={14} />
            Location
          </div>
          <p className="mt-2 font-medium text-surface-900 dark:text-white">
            {emergency.latitude && emergency.longitude ? `${emergency.latitude.toFixed(4)}, ${emergency.longitude.toFixed(4)}` : 'Awaiting coordinates'}
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default EmergencyStatusCard;
