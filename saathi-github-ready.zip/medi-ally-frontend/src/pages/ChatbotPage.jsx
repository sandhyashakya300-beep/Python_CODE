import React from 'react';
import { MessageCircle, Shield, HeartPulse, Stethoscope } from 'lucide-react';

const guidance = [
  {
    title: 'Emergency First Aid',
    text: 'Keep calm, call emergency services if needed, and share the patient location, allergies, and current medications immediately.',
    icon: HeartPulse,
  },
  {
    title: 'Medication Safety',
    text: 'Record all prescriptions, allergies, and medicines accurately so responders and clinicians have the right information quickly.',
    icon: Shield,
  },
  {
    title: 'When to Seek Urgent Help',
    text: 'Seek immediate care for severe chest pain, breathing problems, loss of consciousness, heavy bleeding, or sudden confusion.',
    icon: Stethoscope,
  },
];

const ChatbotPage = () => {
  return (
    <div className="page-transition max-w-4xl mx-auto space-y-6">
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-surface-900 dark:text-white flex items-center gap-2">
          <MessageCircle className="text-primary-500" /> Health Information
        </h1>
        <p className="text-sm text-surface-500 mt-1">Quick, non-AI guidance for emergency readiness and basic healthcare awareness.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {guidance.map(({ title, text, icon: Icon }) => (
          <div key={title} className="bg-white dark:bg-surface-800 rounded-2xl border border-surface-100 dark:border-surface-700 p-5 shadow-soft">
            <div className="w-11 h-11 rounded-xl bg-primary-50 dark:bg-primary-900/20 flex items-center justify-center mb-4">
              <Icon className="text-primary-500" size={20} />
            </div>
            <h3 className="text-base font-semibold text-surface-900 dark:text-white mb-2">{title}</h3>
            <p className="text-sm text-surface-500 leading-relaxed">{text}</p>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-surface-800 rounded-2xl border border-surface-100 dark:border-surface-700 p-6 shadow-soft">
        <h2 className="text-lg font-semibold text-surface-900 dark:text-white mb-3">Emergency readiness checklist</h2>
        <ul className="space-y-2 text-sm text-surface-600 dark:text-surface-300">
          <li>• Keep blood group, allergies, and medications saved in your profile.</li>
          <li>• Add trusted emergency contacts with phone numbers.</li>
          <li>• Allow location access when an emergency is triggered.</li>
          <li>• Share a short description of what happened to help responders.</li>
        </ul>
      </div>
    </div>
  );
};

export default ChatbotPage;
