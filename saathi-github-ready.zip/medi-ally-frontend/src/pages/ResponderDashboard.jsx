import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Activity, AlertTriangle, CheckCircle, MapPin, Radio, ShieldAlert } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../services/api';
import socket from '../services/socket';
import Button from '../components/common/Button';
import { useAuth } from '../context/AuthContext';

const formatStatus = (status) => {
  switch (status) {
    case 'SEARCHING':
      return 'Searching';
    case 'ACCEPTED':
      return 'Accepted';
    case 'RESOLVED':
      return 'Resolved';
    case 'CANCELLED':
      return 'Cancelled';
    default:
      return status || 'Unknown';
  }
};

const ResponderDashboard = () => {
  const { user } = useAuth();
  const [available, setAvailable] = useState(false);
  const [loading, setLoading] = useState(true);
  const [emergencies, setEmergencies] = useState([]);
  const [location, setLocation] = useState({ latitude: null, longitude: null });

  const fetchEmergencies = async () => {
    try {
      const response = await api.get('/emergencies');
      const active = (response.data.emergencies || []).filter(
        (emergency) => !['RESOLVED', 'CANCELLED'].includes(emergency.status)
      );
      setEmergencies(active);
    } catch (error) {
      console.error('Unable to load emergencies:', error);
      toast.error(error.response?.data?.message || 'Unable to load active emergencies.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmergencies();

    socket.on('emergency:update', fetchEmergencies);
    socket.on('responder:update', fetchEmergencies);

    return () => {
      socket.off('emergency:update', fetchEmergencies);
      socket.off('responder:update', fetchEmergencies);
    };
  }, []);

  const resolveCoords = async () => {
    if (location.latitude && location.longitude) {
      return location;
    }

    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported in this browser.'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const nextLocation = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
          };
          setLocation(nextLocation);
          resolve(nextLocation);
        },
        (error) => reject(new Error(error.message || 'Unable to access your location.')),
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 }
      );
    });
  };

  const handleAvailabilityToggle = async (nextAvailability) => {
    try {
      const coords = await resolveCoords();
      await api.post('/responders/availability', {
        available: nextAvailability,
        latitude: coords.latitude,
        longitude: coords.longitude,
      });
      setAvailable(nextAvailability);
      toast.success(nextAvailability ? 'You are now marked as available.' : 'You are now offline.');
    } catch (error) {
      toast.error(error.message || error.response?.data?.message || 'Unable to update availability.');
    }
  };

  const handleAccept = async (emergencyId) => {
    try {
      await api.post(`/emergencies/${emergencyId}/accept`);
      toast.success('Emergency accepted and dispatched to your queue.');
      await fetchEmergencies();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Unable to accept this emergency.');
    }
  };

  const handleResolve = async (emergencyId) => {
    try {
      await api.post(`/emergencies/${emergencyId}/resolve`);
      toast.success('Emergency marked as resolved.');
      await fetchEmergencies();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Unable to resolve this emergency.');
    }
  };

  return (
    <div className="page-transition space-y-6">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-primary-500">Responder hub</p>
          <h1 className="text-2xl font-bold text-surface-900 dark:text-white">
            Welcome back, {user?.name?.split(' ')[0] || 'Responder'}
          </h1>
        </div>

        <div className="flex gap-3">
          <Button variant={available ? 'secondary' : 'primary'} onClick={() => handleAvailabilityToggle(true)}>
            <Radio size={16} /> Available
          </Button>
          <Button variant="ghost" onClick={() => handleAvailabilityToggle(false)}>
            Offline
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-surface-200 bg-white p-4 shadow-soft dark:border-surface-700 dark:bg-surface-800">
          <div className="flex items-center justify-between">
            <span className="text-sm text-surface-500">Active calls</span>
            <AlertTriangle className="text-danger-500" size={18} />
          </div>
          <p className="mt-4 text-3xl font-bold text-surface-900 dark:text-white">{emergencies.length}</p>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="rounded-2xl border border-surface-200 bg-white p-4 shadow-soft dark:border-surface-700 dark:bg-surface-800">
          <div className="flex items-center justify-between">
            <span className="text-sm text-surface-500">Status</span>
            <Activity className="text-primary-500" size={18} />
          </div>
          <p className="mt-4 text-lg font-bold text-surface-900 dark:text-white">{available ? 'On duty' : 'Offline'}</p>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="rounded-2xl border border-surface-200 bg-white p-4 shadow-soft dark:border-surface-700 dark:bg-surface-800">
          <div className="flex items-center justify-between">
            <span className="text-sm text-surface-500">Location</span>
            <MapPin className="text-secondary-500" size={18} />
          </div>
          <p className="mt-4 text-sm font-medium text-surface-700 dark:text-surface-200">
            {location.latitude && location.longitude ? `${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}` : 'Waiting for GPS'}
          </p>
        </motion.div>
      </div>

      <div className="rounded-2xl border border-surface-200 bg-white p-5 shadow-soft dark:border-surface-700 dark:bg-surface-800">
        <div className="mb-4 flex items-center gap-2">
          <ShieldAlert className="text-danger-500" size={18} />
          <h2 className="text-lg font-bold text-surface-900 dark:text-white">Incoming emergencies</h2>
        </div>

        {loading ? (
          <div className="py-10 text-center text-sm text-surface-500">Loading emergency feed…</div>
        ) : emergencies.length === 0 ? (
          <div className="py-10 text-center text-sm text-surface-500">
            No active incidents in your region right now.
          </div>
        ) : (
          <div className="space-y-4">
            {emergencies.map((emergency) => (
              <div key={emergency.id} className="rounded-2xl border border-surface-200 bg-surface-50 p-4 dark:border-surface-700 dark:bg-surface-900/60">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="rounded-full bg-danger-100 px-2.5 py-1 text-xs font-semibold text-danger-600">
                        {emergency.publicId}
                      </span>
                      <span className="rounded-full bg-primary-100 px-2.5 py-1 text-xs font-semibold text-primary-600">
                        {emergency.type}
                      </span>
                    </div>
                    <p className="text-base font-semibold text-surface-900 dark:text-white">{emergency.description || 'Medical emergency response needed'}</p>
                    <div className="flex flex-wrap items-center gap-3 text-sm text-surface-500">
                      <span className="inline-flex items-center gap-1"><MapPin size={14} /> {emergency.latitude}, {emergency.longitude}</span>
                      <span className="inline-flex items-center gap-1"><CheckCircle size={14} /> {formatStatus(emergency.status)}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Button variant="primary" onClick={() => handleAccept(emergency.id)}>
                      Accept
                    </Button>
                    <Button variant="secondary" onClick={() => handleResolve(emergency.id)}>
                      Resolve
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ResponderDashboard;
