import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { User, Save } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import UserProfile from '../components/profile/UserProfile';
import MedicalHistory from '../components/profile/MedicalHistory';
import Settings from '../components/profile/Settings';
import { calculateBMI, getBMIInfo } from '../utils/medicalCalculations';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import toast from 'react-hot-toast';

const toArrayString = (value) => {
  if (!Array.isArray(value)) return '';
  return value.join(', ');
};

const parseListField = (value) => {
  return String(value || '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
};

const parseEmergencyContacts = (value) => {
  if (!Array.isArray(value)) return '';
  return value
    .map((contact) => {
      if (typeof contact === 'string') return contact;
      if (contact && typeof contact === 'object') {
        return `${contact.name || 'Contact'} - ${contact.relation || 'Contact'} - ${contact.phone || ''}`;
      }
      return '';
    })
    .filter(Boolean)
    .join('\n');
};

const ProfilePage = () => {
  const { user, updateUser, saveProfile } = useAuth();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    age: user?.age ?? '',
    height: user?.height ?? '',
    weight: user?.weight ?? '',
    bloodGroup: user?.bloodGroup || '',
    allergies: toArrayString(user?.allergies || []),
    conditions: toArrayString(user?.conditions || []),
    medications: toArrayString(user?.medications || []),
    emergencyContacts: parseEmergencyContacts(user?.emergencyContacts || []),
  });

  useEffect(() => {
    if (!user) return;

    setForm({
      name: user.name || '',
      phone: user.phone || '',
      age: user.age ?? '',
      height: user.height ?? '',
      weight: user.weight ?? '',
      bloodGroup: user.bloodGroup || '',
      allergies: toArrayString(user.allergies || []),
      conditions: toArrayString(user.conditions || []),
      medications: toArrayString(user.medications || []),
      emergencyContacts: parseEmergencyContacts(user.emergencyContacts || []),
    });
  }, [user]);

  const bmi = calculateBMI(Number(form.weight) || user?.weight, Number(form.height) || user?.height);
  const bmiInfo = getBMIInfo(bmi);

  const handleSave = () => {
    const allergies = parseListField(form.allergies);
    const conditions = parseListField(form.conditions);
    const medications = parseListField(form.medications);
    const emergencyContacts = String(form.emergencyContacts || '')
      .split(/\n|;/)
      .map((item) => item.trim())
      .filter(Boolean)
      .map((item) => {
        const parts = item.split(/[-–:]/).map((part) => part.trim());
        const name = parts[0] || 'Emergency Contact';
        const relation = parts[1] || 'Contact';
        const phone = parts[2] || parts[0];

        return { name, relation, phone };
      });

    updateUser({
      name: form.name,
      phone: form.phone,
      age: Number(form.age) || null,
      height: Number(form.height) || null,
      weight: Number(form.weight) || null,
      bloodGroup: form.bloodGroup,
    });

    saveProfile({
      age: Number(form.age) || null,
      height: Number(form.height) || null,
      weight: Number(form.weight) || null,
      bloodGroup: form.bloodGroup,
      allergies,
      conditions,
      medications,
      emergencyContacts,
      medicalHistory: user?.medicalHistory || [],
    });

    setEditing(false);
    toast.success('Profile updated!');
  };

  return (
    <div className="page-transition space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-surface-900 dark:text-white flex items-center gap-2">
          <User className="text-primary-500" /> My Profile
        </h1>
        <p className="text-sm text-surface-500 mt-1">Manage your emergency medical profile and readiness data</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <UserProfile />

          <Card hover={false}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-surface-900 dark:text-white">Edit Medical Profile</h3>
              <button onClick={() => setEditing(!editing)} className="text-sm text-primary-500 font-medium hover:underline">
                {editing ? 'Cancel' : 'Edit'}
              </button>
            </div>
            {editing && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                <Input label="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                <Input label="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                <div className="grid grid-cols-3 gap-3">
                  <Input label="Age" type="number" value={form.age} onChange={(e) => setForm({ ...form, age: e.target.value })} />
                  <Input label="Height (cm)" type="number" value={form.height} onChange={(e) => setForm({ ...form, height: e.target.value })} />
                  <Input label="Weight (kg)" type="number" value={form.weight} onChange={(e) => setForm({ ...form, weight: e.target.value })} />
                </div>
                <Input label="Blood Group" value={form.bloodGroup} onChange={(e) => setForm({ ...form, bloodGroup: e.target.value })} placeholder="e.g., B+" />

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wide text-surface-500 dark:text-surface-400 mb-2">
                    Allergies
                  </label>
                  <textarea
                    value={form.allergies}
                    onChange={(e) => setForm({ ...form, allergies: e.target.value })}
                    rows={3}
                    className="w-full rounded-xl border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 px-3 py-2.5 text-sm text-surface-900 dark:text-white focus:border-primary-500 focus:outline-none"
                    placeholder="Penicillin, peanuts, shellfish"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wide text-surface-500 dark:text-surface-400 mb-2">
                    Conditions
                  </label>
                  <textarea
                    value={form.conditions}
                    onChange={(e) => setForm({ ...form, conditions: e.target.value })}
                    rows={3}
                    className="w-full rounded-xl border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 px-3 py-2.5 text-sm text-surface-900 dark:text-white focus:border-primary-500 focus:outline-none"
                    placeholder="Asthma, hypertension"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wide text-surface-500 dark:text-surface-400 mb-2">
                    Medications
                  </label>
                  <textarea
                    value={form.medications}
                    onChange={(e) => setForm({ ...form, medications: e.target.value })}
                    rows={3}
                    className="w-full rounded-xl border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 px-3 py-2.5 text-sm text-surface-900 dark:text-white focus:border-primary-500 focus:outline-none"
                    placeholder="Salbutamol, metformin"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wide text-surface-500 dark:text-surface-400 mb-2">
                    Emergency Contacts
                  </label>
                  <textarea
                    value={form.emergencyContacts}
                    onChange={(e) => setForm({ ...form, emergencyContacts: e.target.value })}
                    rows={4}
                    className="w-full rounded-xl border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 px-3 py-2.5 text-sm text-surface-900 dark:text-white focus:border-primary-500 focus:outline-none"
                    placeholder="Mother - Mother - 9876543210"
                  />
                </div>

                <Button onClick={handleSave} icon={Save}>Save Changes</Button>
              </motion.div>
            )}
          </Card>

          {bmi > 0 && (
            <Card hover={false}>
              <h3 className="text-base font-semibold text-surface-900 dark:text-white mb-3">BMI Calculator</h3>
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-2xl font-bold text-white" style={{ backgroundColor: bmiInfo.color }}>
                  {bmi}
                </div>
                <div>
                  <p className="text-lg font-semibold" style={{ color: bmiInfo.color }}>{bmiInfo.category}</p>
                  <p className="text-sm text-surface-500 mt-1">{bmiInfo.advice}</p>
                </div>
              </div>
            </Card>
          )}
        </div>

        <div className="space-y-6">
          <MedicalHistory />
          <Settings />
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
