import { useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import useEmergencyStore from '../store/emergencyStore';
import emergencyService from '../services/emergencyService';
import { useAuth } from '../context/AuthContext';

const useEmergencyAlert = () => {
  const [countdown, setCountdown] = useState(null);
  const [alertSent, setAlertSent] = useState(false);
  const { contacts, triggerSOS, resetSOS } = useEmergencyStore();
  const { user } = useAuth();

  const startSOS = useCallback(async () => {
    let count = 5;
    setCountdown(count);

    const interval = setInterval(() => {
      count -= 1;
      setCountdown(count);
    }, 1000);

    try {
      const location = await emergencyService.getCurrentPosition();

      const patientProfile = {
        age: user?.age ?? user?.profile?.age ?? null,
        bloodGroup: user?.bloodGroup ?? user?.profile?.bloodGroup ?? '',
        allergies: user?.allergies ?? user?.profile?.allergies ?? [],
        conditions: user?.conditions ?? user?.profile?.conditions ?? [],
        medications: user?.medications ?? user?.profile?.medications ?? [],
        emergencyContacts: user?.emergencyContacts ?? user?.profile?.emergencyContacts ?? [],
      };

      const result = await emergencyService.sendSOSAlert(location, contacts, patientProfile);
      triggerSOS();
      setAlertSent(true);
      toast.success(result.message || `Emergency alert sent to ${contacts.length} contacts!`);
      return result;
    } catch (error) {
      toast.error(error.message || 'Unable to send emergency alert. Please try again.');
      throw error;
    } finally {
      clearInterval(interval);
      setCountdown(null);
    }
  }, [contacts, triggerSOS, user]);

  const cancelSOS = useCallback(() => {
    setCountdown(null);
    setAlertSent(false);
    resetSOS();
    toast('SOS cancelled', { icon: '✋' });
  }, [resetSOS]);

  return { countdown, alertSent, startSOS, cancelSOS };
};

export default useEmergencyAlert;
