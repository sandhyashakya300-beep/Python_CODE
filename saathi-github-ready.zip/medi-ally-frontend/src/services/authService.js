import api from './api';

const normalizePayload = (payload = {}) => {
  const user = payload.user || payload;
  const token = payload.token || localStorage.getItem('saathi-token');

  return {
    token,
    user: {
      ...user,
      profile: user.profile || {
        age: user.age ?? null,
        height: user.height ?? null,
        weight: user.weight ?? null,
        bloodGroup: user.bloodGroup || '',
        allergies: Array.isArray(user.allergies) ? user.allergies : [],
        conditions: Array.isArray(user.conditions) ? user.conditions : [],
        medications: Array.isArray(user.medications) ? user.medications : [],
        emergencyContacts: Array.isArray(user.emergencyContacts) ? user.emergencyContacts : [],
        medicalHistory: Array.isArray(user.medicalHistory) ? user.medicalHistory : [],
      },
    },
  };
};

const authService = {
  login: async (email, password) => {
    if (!email || !password) {
      throw new Error('Email and password are required');
    }

    const response = await api.post('/auth/login', { email, password });
    return normalizePayload(response.data);
  },

  register: async (data) => {
    if (!data?.email || !data?.password || !data?.name) {
      throw new Error('All fields required');
    }

    const response = await api.post('/auth/register', {
      name: data.name,
      email: data.email,
      password: data.password,
      phone: data.phone || '',
      role: data.role || 'PATIENT',
    });

    return normalizePayload(response.data);
  },

  logout: async () => {
    localStorage.removeItem('saathi-token');
    localStorage.removeItem('saathi-user');
    return { success: true };
  },
};

export default authService;
