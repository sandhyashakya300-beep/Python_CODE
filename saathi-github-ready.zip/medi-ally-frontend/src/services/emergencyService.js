import api from './api';
import hospitals from '../data/hospitals.json';

const getCurrentPosition = () =>
  new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported in this browser.'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        });
      },
      (error) => reject(new Error(error.message || 'Unable to access your location.')),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 }
    );
  });

const emergencyService = {
  getCurrentPosition,

  getNearbyHospitals: async () => {
    return hospitals.map((hospital) => ({
      ...hospital,
      distance: `${(Math.random() * 10 + 0.5).toFixed(1)} km`,
    }));
  },

  createEmergency: async (payload) => {
    const response = await api.post('/emergencies', payload);
    return response.data;
  },

  sendSOSAlert: async (location, contacts, patientProfile) => {
    const emergencyPayload = {
      type: 'MEDICAL',
      description: 'Emergency alert activated by patient',
      latitude: location?.latitude,
      longitude: location?.longitude,
      accuracy: location?.accuracy,
      medicalSnapshot: patientProfile || {},
    };

    const response = await api.post('/emergencies', emergencyPayload);
    return {
      success: true,
      message: `Alert sent to ${contacts.length || 0} emergency contacts with your location`,
      timestamp: new Date().toISOString(),
      ...response.data,
    };
  },
};

export default emergencyService;
