import React, { createContext, useContext, useState, useEffect } from 'react';

const STORAGE_KEY = 'saathi-user';
const TOKEN_STORAGE_KEY = 'saathi-token';
const AuthContext = createContext();

const normalizeList = (value) => {
  if (Array.isArray(value)) {
    return value
      .map((item) => String(item).trim())
      .filter(Boolean);
  }

  if (typeof value === 'string') {
    return value
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean);
  }

  return [];
};

const normalizeEmergencyContacts = (value) => {
  if (!Array.isArray(value)) return [];

  return value
    .map((contact) => {
      if (typeof contact === 'string') {
        const cleaned = contact.trim();
        if (!cleaned) return null;

        const pieces = cleaned.split(/[-–:|]/).map((item) => item.trim());
        const [name = 'Emergency Contact', relation = 'Contact', phone = ''] = pieces;

        return {
          name,
          relation,
          phone,
        };
      }

      if (contact && typeof contact === 'object') {
        return {
          name: contact.name || 'Emergency Contact',
          relation: contact.relation || 'Contact',
          phone: contact.phone || '',
        };
      }

      return null;
    })
    .filter((contact) => contact && contact.name && contact.phone);
};

const normalizeProfile = (source = {}) => {
  const rawProfile = source.profile || {};

  const parseNumber = (value) => {
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  };

  return {
    age: parseNumber(source.age ?? rawProfile.age),
    height: parseNumber(source.height ?? rawProfile.height),
    weight: parseNumber(source.weight ?? rawProfile.weight),
    bloodGroup: String(source.bloodGroup ?? rawProfile.bloodGroup ?? '').trim(),
    allergies: normalizeList(source.allergies ?? rawProfile.allergies),
    conditions: normalizeList(source.conditions ?? rawProfile.conditions),
    medications: normalizeList(source.medications ?? rawProfile.medications),
    emergencyContacts: normalizeEmergencyContacts(source.emergencyContacts ?? rawProfile.emergencyContacts),
    medicalHistory: normalizeList(source.medicalHistory ?? rawProfile.medicalHistory),
  };
};

const normalizeUser = (userData = {}) => {
  const profile = normalizeProfile(userData);

  const normalized = {
    id: String(userData.id || userData._id || Date.now()),
    name: userData.name || 'Patient',
    email: userData.email || '',
    phone: userData.phone || '',
    role: userData.role || 'PATIENT',
    createdAt: userData.createdAt || new Date().toISOString(),
    age: profile.age,
    height: profile.height,
    weight: profile.weight,
    bloodGroup: profile.bloodGroup,
    allergies: profile.allergies,
    conditions: profile.conditions,
    medications: profile.medications,
    emergencyContacts: profile.emergencyContacts,
    medicalHistory: profile.medicalHistory,
    profile,
  };

  return normalized;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem(TOKEN_STORAGE_KEY) || '');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem(STORAGE_KEY);
    const savedToken = localStorage.getItem(TOKEN_STORAGE_KEY);
    if (savedToken) {
      setToken(savedToken);
    }
    if (!savedUser) {
      setLoading(false);
      return;
    }

    try {
      const parsed = JSON.parse(savedUser);
      setUser(normalizeUser(parsed));
    } catch {
      localStorage.removeItem(STORAGE_KEY);
    } finally {
      setLoading(false);
    }
  }, []);

  const persistSession = (incomingUser, incomingToken) => {
    const normalized = normalizeUser(incomingUser);
    setUser(normalized);
    setToken(incomingToken || token || '');
    localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
    if (incomingToken) {
      localStorage.setItem(TOKEN_STORAGE_KEY, incomingToken);
    }
    return normalized;
  };

  const login = (payload) => {
    const nextPayload = payload.user ? payload : { user: payload, token: payload.token };
    const nextUser = normalizeUser(nextPayload.user || nextPayload);
    const nextToken = nextPayload.token || token;
    return persistSession(nextUser, nextToken);
  };

  const register = (payload) => {
    const nextPayload = payload.user ? payload : { user: payload, token: payload.token };
    const nextUser = normalizeUser(nextPayload.user || nextPayload);
    const nextToken = nextPayload.token || token;
    return persistSession(nextUser, nextToken);
  };

  const logout = () => {
    setUser(null);
    setToken('');
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(TOKEN_STORAGE_KEY);
  };

  const updateUser = (updates) => {
    setUser((currentUser) => {
      const nextUser = normalizeUser({
        ...(currentUser || {}),
        ...updates,
        profile: {
          ...(currentUser?.profile || {}),
          ...(updates.profile || {}),
        },
      });

      localStorage.setItem(STORAGE_KEY, JSON.stringify(nextUser));
      return nextUser;
    });
  };

  const saveProfile = (profileData) => {
    setUser((currentUser) => {
      const nextUser = normalizeUser({
        ...(currentUser || {}),
        profile: {
          ...(currentUser?.profile || {}),
          ...profileData,
        },
      });

      localStorage.setItem(STORAGE_KEY, JSON.stringify(nextUser));
      return nextUser;
    });
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        login,
        register,
        logout,
        updateUser,
        saveProfile,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
